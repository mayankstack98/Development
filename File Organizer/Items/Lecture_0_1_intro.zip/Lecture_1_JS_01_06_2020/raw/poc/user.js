let lib = require("./libModule");
lib.myfn();
// lib.another();
// lib.private();