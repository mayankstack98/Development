module.exports.view = function () {
    console.log("view Has been implemented");
}
